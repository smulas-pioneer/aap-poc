const ApplicationStrings = {

  //SECTION_1:
  SECTION_TITLE_1: 'Investment    Centre',
  SUBSECTION_TITLE_1_1: 'Portfolio management system',
  SUBSECTION_TITLE_1_2: 'Model portfolios',
  SUBSECTION_TITLE_1_3: 'Strategical asset allocation',
  SUBSECTION_TITLE_1_4: 'Tactical asset allocation',
  SECTION_BUTTON_1: 'Objekt\nwählen',

  //SECTION_2:
  SECTION_TITLE_2: 'Investment Governance',
  SUBSECTION_TITLE_2_1: 'CIO cockpit',
  SUBSECTION_TITLE_2_2: 'Aggregated risk analysis',
  SUBSECTION_TITLE_2_3: 'Compliance checks',
  SUBSECTION_TITLE_2_4: 'Stress-tests scenarios',
  SECTION_BUTTON_2: 'Offerte\nbestellen',

  //SECTION_3:
  SECTION_TITLE_3: 'Commercial Governance',
  SUBSECTION_TITLE_3_1: 'Sales action plan monitoring',
  SUBSECTION_TITLE_3_2: 'Budget analysis',
  SUBSECTION_TITLE_3_3: 'Massive proposals',
  SUBSECTION_TITLE_3_4: 'Alerts management',
  SECTION_BUTTON_3: 'Refinanzierung\nauslösen',

  //SECTION_4:
  SECTION_TITLE_4: 'Client Advisory',
  SUBSECTION_TITLE_4_1: 'Portfolio health check',
  SUBSECTION_TITLE_4_2: 'Client constraints',
  SUBSECTION_TITLE_4_3: 'Proposal generation',
  SUBSECTION_TITLE_4_4: 'Reporting',
  SECTION_BUTTON_4: 'Handlungsbedarf\numsetzen',

 

};

export default ApplicationStrings;