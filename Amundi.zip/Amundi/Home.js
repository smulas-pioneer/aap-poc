import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Card from '../uicomponents/js/Card';
import propertyPlanningIcon from '../../images/icons/property-planning.png';
import propertyFinancingIcon from '../../images/icons/property-financing.png';
import propertyManagingIcon from '../../images/icons/property-managing.png';
import wealthManagementIcon from '../../images/icons/wealth-management.png';
import investingIcon from '../../images/icons/investing.png';
import ApplicationConstants from '../constants/ApplicationConstants';
import ApplicationStrings from '../constants/ApplicationStrings';
import List from 'uicomponents/js/List';
import ListItem from 'uicomponents/js/ListItem';
import Button from '../uicomponents/js/Button';

class Home extends Component {
  constructor(props) {
    super(props);
    this.className = 'home';
    this.onListItemClick = this.onListItemClick.bind(this);
  }

  onListItemClick(event, data) {
    if (this.props.onItemSelect) {
      this.props.onItemSelect(data);
    }
  }

  onDPMDashboardClick() {
    if(ApplicationConstants.IS_LOCALE_VERSION) {
      window.location.assign('http://localhost:9000');
      //onStressTestClick
    } else {
      window.location.assign('http://www.codebox.ch/swissquant/ims/dpm/index.html');
    }
  }

  onStressTestClick() {
    if(ApplicationConstants.IS_LOCALE_VERSION) {
      window.location.assign('http://demo.swissquant.com:9004/');
    } else {
      window.location.assign('http://demo.swissquant.com:9004/');
    }
  }

  onSalesActionClick() {
    if(ApplicationConstants.IS_LOCALE_VERSION) {
      window.location.assign('http://datahubp.azurewebsites.net/aap-poc/#/');
    } else {
      window.location.assign('http://datahubp.azurewebsites.net/aap-poc/#/');
    }
  }

  onDPMMpfClick() {
    if(ApplicationConstants.IS_LOCALE_VERSION) {
      window.location.assign('http://ims.swissquant.com:9000?v=1');
    } else {
      window.location.assign('http://www.codebox.ch/swissquant/ims/dpm/index.html?v=1');
    }
  }

  onDPMPortfolioClick() {
    if(ApplicationConstants.IS_LOCALE_VERSION) {
      window.location.assign('http://ims.swissquant.com:9000?v=2');
    } else {
      window.location.assign('http://www.codebox.ch/swissquant/ims/dpm/index.html?v=2');
    }
  }

  onMpfBalEUR2WeightsClick() {
    if(ApplicationConstants.IS_LOCALE_VERSION) {
      window.location.assign('http://ims.swissquant.com:9000?v=3');
    } else {
      window.location.assign('http://www.codebox.ch/swissquant/ims/dpm/index.html?v=3');
    }
  }

  onMpfIncEUR2WeightsClick() {
    if(ApplicationConstants.IS_LOCALE_VERSION) {
      window.location.assign('http://ims.swissquant.com:9000?v=4');
    } else {
      window.location.assign('http://www.codebox.ch/swissquant/ims/dpm/index.html?v=4');
    }
  }

  onMpfInvestigationClick() {
    if(ApplicationConstants.IS_LOCALE_VERSION) {
      window.location.assign('http://ims.swissquant.com:9000?v=5');
    } else {
      window.location.assign('http://www.codebox.ch/swissquant/ims/dpm/index.html?v=5');
    }
  }

  onMasterBalEUR2Click() {
    if(ApplicationConstants.IS_LOCALE_VERSION) {
      window.location.assign('http://ims.swissquant.com:9000?v=6');
    } else {
      window.location.assign('http://www.codebox.ch/swissquant/ims/dpm/index.html?v=6');
    }
  }

  onNewDerivedTacticalAssetAllocations() {
    //Version 1 (localhost)
    window.location.assign('http://ims.swissquant.com:8081/analytics/weights');

    //Version 2 (Server)
    // window.location.assign('http://www.codebox.ch/swissquant/ims/dpm/index.html?v=6');
  }

  render() {
    return (
      <div className={this.props.visible ? this.className : this.className + ' hidden'}>
        <div className='cards'>
             {/*------- Section 4 -------*/}
             <Card
            label={ApplicationStrings.SECTION_TITLE_4}
            icon={<div className='icon' style={{backgroundImage: 'url("' + wealthManagementIcon + '")'}}/>}
          >
            <List>
              <ListItem data={{section: ApplicationConstants.SECTION_4, selectedIndex: 0}} onClick={this.onListItemClick}>
                {ApplicationStrings.SUBSECTION_TITLE_4_1}
              </ListItem>
              <ListItem data={{section: ApplicationConstants.SECTION_4, selectedIndex: 1}} onClick={this.onListItemClick}>
                {ApplicationStrings.SUBSECTION_TITLE_4_2}
              </ListItem>
              <ListItem data={{section: ApplicationConstants.SECTION_4, selectedIndex: 2}} onClick={this.onListItemClick}>
                {ApplicationStrings.SUBSECTION_TITLE_4_3}
              </ListItem>
              <ListItem data={{section: ApplicationConstants.SECTION_4, selectedIndex: 3}} onClick={this.onListItemClick}>
                {ApplicationStrings.SUBSECTION_TITLE_4_4}
              </ListItem>
     
            </List>
              {/*<Button className='card-button' disabled>{ApplicationStrings.SECTION_BUTTON_4}</Button>*/}
          </Card>
     
          {/*------- Section 1 -------*/}
          <Card
            label={ApplicationStrings.SECTION_TITLE_1}
            icon={<div className='icon' style={{backgroundImage: 'url("' + propertyPlanningIcon + '")'}}/>}
          >
            <List>
              <ListItem data={{section: ApplicationConstants.SECTION_1, selectedIndex: 0}} onClick={this.onDPMDashboardClick}>
                {ApplicationStrings.SUBSECTION_TITLE_1_1}
              </ListItem>
              <ListItem data={{section: ApplicationConstants.SECTION_1, selectedIndex: 1}} onClick={this.onDPMDashboardClick}>
                {ApplicationStrings.SUBSECTION_TITLE_1_2}
              </ListItem>
              <ListItem data={{section: ApplicationConstants.SECTION_1, selectedIndex: 2}} onClick={this.onMasterBalEUR2Click}>
                {ApplicationStrings.SUBSECTION_TITLE_1_3}
              </ListItem>
              <ListItem data={{section: ApplicationConstants.SECTION_1, selectedIndex: 3}} onClick={this.onMasterBalEUR2Click}>
                {ApplicationStrings.SUBSECTION_TITLE_1_4}
              </ListItem>
            </List>
              {/*<Button className='card-button' disabled>{ApplicationStrings.SECTION_BUTTON_1}</Button>*/}
          </Card>
          {/*------- Section 2 -------*/}
          <Card
            label={ApplicationStrings.SECTION_TITLE_2}
            icon={<div className='icon' style={{backgroundImage: 'url("' + propertyFinancingIcon + '")'}}/>}
          >
            <List>
              <ListItem data={{section: ApplicationConstants.SECTION_2, selectedIndex: 0}} onClick={this.onDPMDashboardClick}>
                {ApplicationStrings.SUBSECTION_TITLE_2_1}
              </ListItem>
              <ListItem data={{section: ApplicationConstants.SECTION_2, selectedIndex: 1}} onClick={this.onListItemClick}>
                {ApplicationStrings.SUBSECTION_TITLE_2_2}
              </ListItem>
              <ListItem data={{section: ApplicationConstants.SECTION_2, selectedIndex: 1}} onClick={this.onListItemClick}>
                {ApplicationStrings.SUBSECTION_TITLE_2_3}
              </ListItem>
              <ListItem data={{section: ApplicationConstants.SECTION_2, selectedIndex: 1}} onClick={this.onStressTestClick}>
                {ApplicationStrings.SUBSECTION_TITLE_2_4}
              </ListItem>
            </List>
              {/*<Button className='card-button' disabled>{ApplicationStrings.SECTION_BUTTON_2}</Button>*/}
          </Card>
               {/*------- Section 3 -------*/}
               <Card
            label={ApplicationStrings.SECTION_TITLE_3}
            icon={<div className='icon' style={{backgroundImage: 'url("' + propertyManagingIcon + '")'}}/>}
          >
            <List>
              <ListItem data={{section: ApplicationConstants.SECTION_3, selectedIndex: 0}} onClick={this.onSalesActionClick}>
                {ApplicationStrings.SUBSECTION_TITLE_3_1}
              </ListItem>
              <ListItem data={{section: ApplicationConstants.SECTION_3, selectedIndex: 1}} onClick={this.onListItemClick}>
                {ApplicationStrings.SUBSECTION_TITLE_3_2}
              </ListItem>
              <ListItem data={{section: ApplicationConstants.SECTION_3, selectedIndex: 2}} onClick={this.onListItemClick}>
                {ApplicationStrings.SUBSECTION_TITLE_3_3}
              </ListItem>
              <ListItem data={{section: ApplicationConstants.SECTION_3, selectedIndex: 3}} onClick={this.onNewDerivedTacticalAssetAllocations}>
                {ApplicationStrings.SUBSECTION_TITLE_3_4}
              </ListItem>
            </List>
              {/*<Button className='card-button' disabled>{ApplicationStrings.SECTION_BUTTON_3}</Button>*/}
          </Card>
       
          {/*------- Section 5 -------*/}
 
        </div>
      </div>
    );
  }
}


Home.propTypes = {
  visible: PropTypes.bool,
  onItemSelect: PropTypes.func,
};

Home.defaultProps = {
  visible: false,
};

export default Home;